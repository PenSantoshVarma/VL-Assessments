package org.cap.dao;

import org.cap.dto.Product;

public class ProductDaoImpl implements ProductDao{

	public boolean addProduct(Product product) {
		// TODO Auto-generated method stub
		return false;
	}

	public Product findProduct(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

}
