package org.cap.product.test;

public interface GoodTestCategory {

}
