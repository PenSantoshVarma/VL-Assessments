package org.cap.exception;

public class InsufficientQuantityException extends Exception {

}
